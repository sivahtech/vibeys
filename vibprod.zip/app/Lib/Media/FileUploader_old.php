
// uthenticate using keyfile data
$storage = new StorageClient([
    'keyFile' => json_decode(file_get_contents('C:\xampp\htdocs\vibprod\config\google_key_live.json'), true)
]);

// Specify your bucket name
$bucketName = 'vb241866.appspot.com';

// Get the bucket object
$bucket = $storage->bucket($bucketName);