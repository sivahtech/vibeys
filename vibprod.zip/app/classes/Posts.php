<?php

/* Check the absolute path to the Social Auto Poster directory. */
if (!defined('SAP_APP_PATH')) {
	// If SAP_APP_PATH constant is not defined, perform some action, show an error, or exit the script
	// Or exit the script if required
	exit();
}

require_once(SAP_APP_PATH . DS . 'Lib' . DS . 'vendor/autoload.php');

use Orhanerday\OpenAi\OpenAi;

/**
 * Posts Class
 * 
 * Responsible for all function related to posts
 *
 * @package Social Auto Poster
 * @since 1.0.0
 */

require_once(CLASS_PATH . 'Settings.php');
require_once(CLASS_PATH . 'Quick_Posts.php');

class SAP_Posts
{

	//Set Database variable
	private $db;
	//Set table name
	private $table_name;
	private $post_meta_table_name;
	private $settings;
	private $quickPosts;
	public $flash;
	public $common, $sap_common;

	public function __construct()
	{
		global $sap_db_connect, $sap_common;

		$this->db 		= $sap_db_connect;
		$this->flash 	= new Flash();
		$this->common 	= new Common();
		$this->quickPosts = new SAP_Quick_Posts();
		$this->table_name = 'sap_posts';

		$this->post_meta_table_name = 'sap_postmeta';

		$this->settings = new SAP_Settings();
		$this->sap_common = $sap_common;
		// echo '<pre>';
	}

	/**
	 * Listing page of Posts
	 * 
	 * @package Social Auto Poster 
	 * @since 1.0.0
	 */
	public function index()
	{
		//Includes Html files for Posts list
		if (sap_current_user_can('quick-post')) {
			if (isset($_SESSION['user_details']) && !empty($_SESSION['user_details'])) {

				$template_path = $this->common->get_template_path('Posts' . DS . 'posts.php');
				include_once($template_path);
			}
		} else {
			$this->common->redirect('login');
		}
	}

	/**
	 * Add new post
	 * 
	 * @package Social Auto Poster
	 * @since v1.0.0
	 */
	public function add_new_post()
	{

		if (isset($_SESSION['user_details']) && !empty($_SESSION['user_details'])) {

			if (!class_exists('SAP_Tumblr')) {
				require_once(CLASS_PATH . 'Social' . DS . 'tumblrConfig.php');
			}

			$tumblr = new SAP_Tumblr();

			$template_path = $this->common->get_template_path('Posts' . DS . 'add.php');
			include_once($template_path);
		} else {
			$this->common->redirect('login');
		}
	}

	/**
	 * Save posts to database
	 * 
	 * @todo : Set error message
	 * @since v1.0.0
	 */
	public function save_post()
	{
		//Check form submit request
		if (isset($_POST['form-submitted'])) {

			//Check Post Published Or Draft
			$uploads_folder      =  SAP_APP_PATH . 'uploads/';
			$is_uploads_writable =  is_writable($uploads_folder);

			if (!$is_uploads_writable) {

				$this->sap_common->sap_script_logs('Please provide the write permission to the directory ( ' . $uploads_folder . ' )');
				$this->flash->setFlash('Please provide the write permission to the directory ( ' . $uploads_folder . ' )', 'error');
				header("Location:" . SAP_SITE_URL . "/add-new-post/");
			} else {

				$user_id = sap_get_current_user_id();
				if (empty($user_id)) {
					$user_id = $_POST['user_id'];
				}

				$user_options = $this->settings->get_user_setting('sap_general_options', $user_id);

				$timezone = (!empty($user_options['timezone'])) ? $user_options['timezone'] : ''; // user timezone

				//Update time zone based on user setting
				if (!empty($timezone)) { // set default timezone
					date_default_timezone_set($timezone);
				}
				if (isset($__FILES['img'])) {
					//Call Upload class and upload media
					$fileUpload = new FileUploader(array());
					$uploadPath = $fileUpload->uploadFile('img');

					//Check media uploaded
					if (!is_int($uploadPath) || !is_numeric($uploadPath)) {
						$_POST['img'] = $uploadPath;
					} else {
						$_POST['img'] = '';
					}
				} else {
					$uploadPath = '';
				}
				// chech post type is quick or scheduled
				if ((isset($_POST['sap-schedule-from-time']) && !empty($_POST['sap-schedule-from-time'])) && (isset($_POST['sap-schedule-to-time']) && !empty($_POST['sap-schedule-to-time']))) {
					// global scheduled // means scheduled; //Status 2 means whole post set scheduled
					$_POST['status'] = 2;
					$_POST['post_type'] = 2;
				} else {

					if ((!empty($_POST['sap-schedule-from-time-fb']) && !empty($_POST['sap-schedule-to-time-fb'])) ||
						(!empty($_POST['sap-schedule-from-time-blogger']) && !empty($_POST['sap-schedule-to-time-blogger'])) ||
						(!empty($_POST['sap-schedule-from-time-tw']) && !empty($_POST['sap-schedule-to-time-tw'])) ||
						(!empty($_POST['sap-schedule-from-time-li']) && !empty($_POST['sap-schedule-to-time-li'])) ||
						(!empty($_POST['sap-schedule-from-time-tumblr']) && !empty($_POST['sap-schedule-to-time-tumblr'])) ||
						(!empty($_POST['sap-schedule-from-time-pin']) && !empty($_POST['sap-schedule-to-time-pin'])) ||
						(!empty($_POST['sap-schedule-from-time-gmb']) && !empty($_POST['sap-schedule-to-time-gmb'])) ||
						(!empty($_POST['sap-schedule-from-time-instagram']) && !empty($_POST['sap-schedule-to-time-instagram'])) ||
						(!empty($_POST['sap-schedule-from-time-reddit']) && !empty($_POST['sap-schedule-to-time-reddit']))
					) {
						// individual post  2 means whole post set scheduled
						$_POST['status'] = 2;
						$_POST['individual_status'] = 2;
						$_POST['post_type'] = 2;
					}

					if ((empty($_POST['sap-schedule-from-time-fb']) && empty($_POST['sap-schedule-to-time-fb']) && isset($_POST['networks']['facebook'])) ||
						(empty($_POST['sap-schedule-from-time-blogger']) && empty($_POST['sap-schedule-to-time-blogger']) && isset($_POST['networks']['blogger'])) ||
						(empty($_POST['sap-schedule-from-time-tw']) && empty($_POST['sap-schedule-to-time-tw']) && isset($_POST['networks']['twitter'])) ||
						(empty($_POST['sap-schedule-from-time-li']) && empty($_POST['sap-schedule-from-time-li']) && isset($_POST['networks']['linkedin'])) ||
						(empty($_POST['sap-schedule-from-time-tumblr']) && empty($_POST['sap-schedule-time-tumblr']) && isset($_POST['networks']['tumblr'])) ||
						(empty($_POST['sap-schedule-from-time-pin']) && empty($_POST['sap-schedule-to-time-pin']) && isset($_POST['networks']['pinterest'])) ||
						(empty($_POST['sap-schedule-from-time-tumblr']) && empty($_POST['sap-schedule-to-time-tumblr']) && isset($_POST['networks']['gmb'])) ||
						(empty($_POST['sap-schedule-from-time-gmb']) && empty($_POST['sap-schedule-to-time-gmb']) && isset($_POST['networks']['instagram'])) ||
						(empty($_POST['sap-schedule-from-time-reddit']) && empty($_POST['sap-schedule-to-time-reddit']) && isset($_POST['networks']['reddit']))
					) {
						$_POST['individual_status'] = 1;
					}
				}


				$_POST['img'] = $uploadPath;
				$_POST['ip'] = $this->common->get_user_ip();

				$_POST['body'] = !empty($_POST['body']) ? $this->db->filter($this->db->clean($_POST['body'])) : '';

				$_POST['created_date'] = date('Y-m-d H:i:s');

				if (isset($_POST['ai_image_link']) && !empty($_POST['ai_image_link'])) {
					$_POST['img'] =  $this->settings->uploadImageFromUrl($_POST['ai_image_link']);
				}

				if (isset($_POST['post_type'])  && $_POST['status'] == 2) {
					$status = 1;
				} else {
					$status = 1;
				}

				//Prepare data for store post in DB
				$prepare_data = array(
					'user_id'		=> $user_id,
					'body'			=> $_POST['body'],
					'img'			=> $_POST['img'],
					'ip_address'	=> $_POST['ip'],
					'status'		=> $status,
					'created_date'	=> $_POST['created_date'],
					'post_type'     => isset($_POST['post_type']) ? $_POST['post_type'] : 1,
				);

				if (isset($_POST['share_link'])) {
					$prepare_data['share_link'] = $_POST['share_link'];
				}

				if (isset($_POST['title']) && !empty($_POST['title'])) {
					$prepare_data['title'] = $_POST['title'];
				}
				if (isset($_POST['image_title']) && !empty($_POST['image_title'])) {
					$prepare_data['image_title'] = $_POST['image_title'];
				}

				if (isset($_POST['sap_reddit_post_type']) && !empty($_POST['sap_reddit_post_type']) && $_POST['sap_reddit_post_type'] == 'link') {

					if (empty($prepare_data['share_link'])) {
						$this->flash->setFlash($this->sap_common->lang('reddit_link_error_msg'), 'error');
						header("Location:" . SAP_SITE_URL . "/add-new-post/");
						exit;
					}
				}

				$prepare_data = $this->db->escape($prepare_data);
				if ($this->db->insert($this->table_name, $prepare_data)) {

					$_POST['id'] = $this->db->lastid();

					// update meta value for the post
					$this->save_post_meta();

					//Check Post Published Or Draft
					if (isset($_POST['status'])) {

						if (isset($_POST['individual_status']) && $_POST['individual_status'] == 1 && $_POST['status'] != 1) {
							// if (isset($_POST['individual_status']) && $_POST['status'] != 1) {

							$this->sap_manage_wall_social_post($_POST['id'], $_POST['individual_status'], $user_id);  // for quick posts
						}

						// $this->sap_manage_wall_social_post($_POST['id'], $_POST['status'], $user_id); // for scheduled 
						$this->sap_manage_wall_social_post($_POST['id'], $_POST['individual_status'] = 1, $user_id); // for scheduled 
					} else {
						$this->flash->setFlash($this->sap_common->lang('content_draft_save'), 'success');
					}

					if (isset($_POST['is_ai_post']) && !empty($_POST['is_ai_post'])) {
						return true;
					} else {
						header("Location:" . SAP_SITE_URL . "/posts/view/" . $_POST['id']);
						exit;
					}
				} else {
					$this->flash->setFlash($this->sap_common->lang('saving_data_error_msg'), 'error');
				}
			}
		}
	}

	/**
	 * View Posts
	 * 
	 * @package Social Auto Poster
	 * @since 1.0.0
	 */
	public function view_post()
	{
		if (isset($_SESSION['user_details']) && !empty($_SESSION['user_details'])) {
			if (!class_exists('SAP_Tumblr')) {
				require_once(CLASS_PATH . 'Social' . DS . 'tumblrConfig.php');
			}

			$tumblr = new SAP_Tumblr();

			$template_path = $this->common->get_template_path('Posts' . DS . 'edit.php');
			include_once($template_path);
		} else {
			$this->common->redirect('login');
		}
	}

	/**
	 * Update Post
	 * 
	 * @package Social Auto Poster
	 * @since 1.0.0
	 */
	public function update_post()
	{


		if (isset($_POST['form-updated'])) {

			$post_id = $_POST['id'];

			//Call Upload class and upload media
			$fileUpload = new FileUploader(array());

			if (!empty($_FILES['img'])) {
				$uploadPath = $fileUpload->uploadFile('img');
			}

			//Check media uploaded
			if (!is_int($uploadPath) || !is_numeric($uploadPath)) {
				$post_img = $uploadPath;
			} else {
				$post_img = $_POST['edit_image'];
			}

			$user_id = sap_get_current_user_id();

			$user_options = $this->settings->get_user_setting('sap_general_options', $user_id);

			$timezone = (!empty($user_options['timezone'])) ? $user_options['timezone'] : ''; // user timezone

			//Update time zone based on user setting
			if (!empty($timezone)) { // set default timezone
				date_default_timezone_set($timezone);
			}

			// chech post type is quick or scheduled
			if ((isset($_POST['sap-schedule-from-time']) && !empty($_POST['sap-schedule-from-time'])) && (isset($_POST['sap-schedule-to-time']) && !empty($_POST['sap-schedule-to-time']))) {
				// global scheduled // means scheduled; //Status 2 means whole post set scheduled
				$_POST['status'] = 2;
			} else {

				if ((!empty($_POST['sap-schedule-from-time-fb']) && !empty($_POST['sap-schedule-to-time-fb'])) ||
					(!empty($_POST['sap-schedule-from-time-blogger']) && !empty($_POST['sap-schedule-to-time-blogger'])) ||
					(!empty($_POST['sap-schedule-from-time-tw']) && !empty($_POST['sap-schedule-to-time-tw'])) ||
					(!empty($_POST['sap-schedule-from-time-li']) && !empty($_POST['sap-schedule-to-time-li'])) ||
					(!empty($_POST['sap-schedule-from-time-tumblr']) && !empty($_POST['sap-schedule-to-time-tumblr'])) ||
					(!empty($_POST['sap-schedule-from-time-pin']) && !empty($_POST['sap-schedule-to-time-pin'])) ||
					(!empty($_POST['sap-schedule-from-time-gmb']) && !empty($_POST['sap-schedule-to-time-gmb'])) ||
					(!empty($_POST['sap-schedule-from-time-instagram']) && !empty($_POST['sap-schedule-to-time-instagram'])) ||
					(!empty($_POST['sap-schedule-from-time-reddit']) && !empty($_POST['sap-schedule-to-time-reddit']))
				) {
					// individual post  2 means whole post set scheduled
					$_POST['status'] = 2;
					$_POST['individual_status'] = 2;
				}


				if ((empty($_POST['sap-schedule-from-time-fb']) && empty($_POST['sap-schedule-to-time-fb']) && isset($_POST['networks']['facebook'])) ||
					(empty($_POST['sap-schedule-from-time-blogger']) && empty($_POST['sap-schedule-to-time-blogger']) && isset($_POST['networks']['blogger'])) ||
					(empty($_POST['sap-schedule-from-time-tw']) && empty($_POST['sap-schedule-to-time-tw']) && isset($_POST['networks']['twitter'])) ||
					(empty($_POST['sap-schedule-from-time-li']) && empty($_POST['sap-schedule-from-time-li']) && isset($_POST['networks']['linkedin'])) ||
					(empty($_POST['sap-schedule-from-time-tumblr']) && empty($_POST['sap-schedule-time-tumblr']) && isset($_POST['networks']['tumblr'])) ||
					(empty($_POST['sap-schedule-from-time-pin']) && empty($_POST['sap-schedule-to-time-pin']) && isset($_POST['networks']['pinterest'])) ||
					(empty($_POST['sap-schedule-from-time-tumblr']) && empty($_POST['sap-schedule-to-time-tumblr']) && isset($_POST['networks']['gmb'])) ||
					(empty($_POST['sap-schedule-from-time-gmb']) && empty($_POST['sap-schedule-to-time-gmb']) && isset($_POST['networks']['instagram'])) ||
					(empty($_POST['sap-schedule-from-time-reddit']) && empty($_POST['sap-schedule-to-time-reddit']) && isset($_POST['networks']['reddit']))
				) {
					$_POST['individual_status'] = 1;
				}
			}

			if (isset($_POST['sap_reddit_post_type']) && !empty($_POST['sap_reddit_post_type']) && $_POST['sap_reddit_post_type'] == 'link') {

				if (empty($prepare_data['share_link'])) {
					$this->flash->setFlash($this->sap_common->lang('reddit_link_error_msg'), 'error');
					header("Location:" . SAP_SITE_URL . "/posts/view/" . $_POST['id']);
					exit;
				}
			}

			if (isset($_POST['ai_image_link']) && !empty($_POST['ai_image_link'])) {
				$post_img =  $this->settings->uploadImageFromUrl($_POST['ai_image_link']);
			}

			$_POST['img'] 	= $post_img;
			$_POST['ip'] 	= $this->common->get_user_ip();
			$_POST['body'] 	= $this->db->filter($_POST['body']);
			$_POST['modified_date'] = date('Y-m-d H:i:s');

			//Prepare data for store post in DB
			$prepare_data = array(
				'body' => $_POST['body'],
				'img' => $_POST['img'],
				'status' => isset($_POST['status']) ? $_POST['status'] : 0,
				'modified_date' => $_POST['modified_date'],
			);

			if (isset($_POST['share_link'])) {
				$prepare_data['share_link'] = $_POST['share_link'];
			}

			if (isset($_POST['title']) && !empty($_POST['title'])) {
				$prepare_data['title'] = $_POST['title'];
			}
			if (isset($_POST['image_title']) && !empty($_POST['image_title'])) {
				$prepare_data['image_title'] = $_POST['image_title'];
			}

			$prepare_data = $this->db->escape($prepare_data);

			if ($this->db->update($this->table_name, $prepare_data, array('post_id' => $post_id))) {

				// update meta value for the post
				$this->save_post_meta();

				//Check Post Published Or Draft
				if (isset($_POST['status'])) {

					// if (isset($_POST['individual_status']) && $_POST['status'] != 1) {
					if (isset($_POST['individual_status']) && $_POST['individual_status'] == 1 && $_POST['status'] != 1) {

						$this->sap_manage_wall_social_post($_POST['id'], $_POST['individual_status'], $user_id);
					}
					$this->sap_manage_wall_social_post($_POST['id'], $_POST['status'], $user_id);
				}

				header("Location:" . SAP_SITE_URL . "/posts/view/" . $_POST['id']);
				exit;
			} else {
				$this->flash->setFlash($this->sap_common->lang('saving_data_error_msg'), 'error');
			}
		}
	}

	/**
	 * Update Quick Post
	 * 
	 * @package Social Auto Poster
	 * @since 1.0.0
	 */
	public function update_posts($prepare_data, $where_data)
	{

		if (!empty($prepare_data) && !empty($where_data)) {
			//Run update query in db and return result
			return $this->db->update($this->table_name, $prepare_data, $where_data);
		}
	}

	/**
	 * Delete Posts
	 * 
	 * @package Social Auto Poster
	 * @since 1.0.0
	 */
	public function delete_post()
	{

		if (!empty($_REQUEST['post_id'])) {
			$result = array();
			$post_id = $_REQUEST['post_id'];
			$img_path = '';
			$sap_img = '';

			$result = $this->db->get_results("SELECT * FROM " . $this->table_name . " where `post_id` = " . $post_id);

			$sap_img = $this->get_post_meta($post_id, '_sap_fb_post_image');

			if (isset($sap_img) && !empty($sap_img)) {
				$sap_img = 	SAP_APP_PATH . 'uploads/' . $sap_img;
			}

			$img_meta = $result[0]->img;

			if (isset($img_meta) && !empty($img_meta)) {

				$img_path = SAP_APP_PATH . 'uploads/' . $result[0]->img;
			}

			$conditions = array('post_id' => $post_id);
			$is_deleted = $this->db->delete($this->table_name, $conditions);
			$this->db->delete($this->post_meta_table_name, $conditions);

			if ($is_deleted) {
				$result = array('status' => '1');
				unlink($img_path);
				unlink($sap_img);
			} else {
				$result = array('status' => '0');
			}
			echo json_encode($result);
			die;
		}
	}

	/**
	 * Delete Multiple posts
	 * 
	 * @package Social Auto Poster
	 * @since 1.0.0
	 */
	public function delete_multiple_post()
	{

		if (!empty($_REQUEST['id'])) {
			$result = array();
			$post_id = $_REQUEST['id'];
			foreach ($post_id as $key => $value) {
				$conditions = array('post_id' => $value);
				$is_deleted = $this->db->delete($this->table_name, $conditions);
				$this->db->delete($this->post_meta_table_name, $conditions);
			}
			if ($is_deleted) {
				$result = array('status' => '1');
				$this->flash->setFlash($this->sap_common->lang('select_post_delete'), 'success');
			} else {
				$result = array('status' => '0');
			}
			echo json_encode($result);
			die;
		}
	}

	/**
	 * Get post settings
	 * 
	 * Handels list setting Option get
	 * 
	 * @package Social Auto Poster
	 * @since 1.0.0
	 */
	public function get_post($post_id, $object)
	{

		$result = array();
		if (isset($post_id) && !empty($post_id)) {
			try {
				$result = $this->db->get_row("SELECT * FROM " . $this->table_name . " where `post_id` = '{$post_id}'", $object);
			} catch (Exception $e) {
				return $e->getMessage();
			}
			//Return result
			return $result;
		}
	}

	/**
	 * Get all posts
	 * 
	 * Handels post listing
	 * 
	 * @package Social Auto Poster
	 * @since 1.0.0
	 */
	public function get_posts()
	{
		$result = array();
		try {
			$user_id = sap_get_current_user_id();

			$result = $this->db->get_results("SELECT * FROM " . $this->table_name . " WHERE `user_id` = {$user_id} ORDER BY `created_date` DESC");
		} catch (Exception $e) {
			return $e->getMessage();
		}

		//Return result
		return $result;
	}

	/**
	 * Update option settings
	 * 
	 * Handels to insert post meta
	 * 
	 * @package Social Auto Poster
	 * @since 1.0.0
	 */
	public function insert_post_meta($post_id, $meta_key, $meta_value)
	{
		if (!empty($post_id) && !empty($meta_key)) {
			$post_meta_data = array('post_id' => $post_id, 'meta_key' => $meta_key, 'meta_value' => is_array($meta_value) ? serialize($meta_value) : $meta_value);
			//Run query and insert option in db

			$post_meta_data = $this->db->escape($post_meta_data);
			$this->db->insert($this->post_meta_table_name, $post_meta_data);

			//Return inserted ID
			return $this->db->lastid();
		}
	}

	/**
	 * Update option settings
	 * 
	 * Handels to Update post meta
	 * 
	 * @package Social Auto Poster
	 * @since 1.0.0
	 */
	public function update_post_meta($post_id, $meta_key, $meta_value)
	{

		if (!empty($post_id) && !empty($meta_key)) {
			//Check option exist in Database
			$check_postmeta_exist = $this->db->num_rows("SELECT * FROM " . $this->post_meta_table_name . " WHERE post_id = '{$post_id}' AND meta_key = '{$meta_key}' ");

			//Exist database set update query another insert option
			if ($check_postmeta_exist) {

				//Prepare data for update
				$post_meta_data = array('post_id' => $post_id, 'meta_key' => $meta_key, 'meta_value' => is_array($meta_value) ? serialize($meta_value) : $this->db->filter($meta_value));
				$where_data = array('post_id' => $post_id, 'meta_key' => $meta_key);

				//Run update query in db and return result
				return $this->db->update($this->post_meta_table_name, $post_meta_data, $where_data);
			} else {

				//Prepare data for insert
				$post_meta_data = array('post_id' => $post_id, 'meta_key' => $meta_key, 'meta_value' => is_array($meta_value) ? serialize($meta_value) : $this->db->filter($meta_value));

				//Run query and insert option in db
				$this->db->insert($this->post_meta_table_name, $post_meta_data);

				//Return inserted ID
				return $this->db->lastid();
			}
		}
	}

	/**
	 * Delete option settings
	 * 
	 * Handels to delete post meta
	 * 
	 * @package Social Auto Poster
	 * @since 1.0.0
	 */
	public function delete_post_meta($post_id, $meta_key)
	{

		if (!empty($post_id) && !empty($meta_key)) {
			$post_meta_data = array('post_id' => $post_id, 'meta_key' => $meta_key);
			//Run database and Insert options in table
			$result = $this->db->delete($this->post_meta_table_name, $post_meta_data);

			//Return result
			return $result;
		}
	}

	/**
	 * Update option settings
	 *  
	 * Handels to get post meta
	 * 
	 * @package Social Auto Poster
	 * @since 1.0.0
	 */
	public function get_post_meta($post_id, $meta_key)
	{

		if (!empty($post_id) && !empty($meta_key)) {
			//Check option exist in Database
			$postmeta_data = $this->db->get_row("SELECT * FROM " . $this->post_meta_table_name . " WHERE post_id = '{$post_id}' AND meta_key = '{$meta_key}' ");

			if (isset($postmeta_data[3]) && $this->common->is_serialized($postmeta_data[3])) {
				$result = unserialize($postmeta_data[3]);
			} elseif (isset($postmeta_data[3]) && is_string($postmeta_data[3])) {
				$result = $postmeta_data[3];
			} else {
				$result = '';
			}
			return $result;
		}
	}

	/**
	 * Reset option settings
	 * 
	 * Handels to reset post status
	 * 
	 * @package Social Auto Poster
	 * @since 1.0.0
	 */
	public function reset_post_status()
	{

		if (!empty($_REQUEST['post_id']) && !empty($_REQUEST['meta_key'])) {

			$result = array();
			$post_id = $_REQUEST['post_id'];
			$meta_key = $_REQUEST['meta_key'];

			$is_deleted = $this->delete_post_meta($post_id, $meta_key);
			if ($is_deleted) {
				$is_display_schedule = $this->is_display_schedule($post_id);
				$result = array('status' => '1', 'is_display_schedule' => $is_display_schedule);
			} else {
				$result = array('status' => '0');
			}
			echo json_encode($result);
			die;
		}
	}

	/**
	 * Reset option settings
	 * 
	 * Handels to reset post status
	 * 
	 * @package Social Auto Poster
	 * @since 1.0.0
	 */
	public function is_display_schedule($post_id)
	{

		$_sap_fb_status = $this->get_post_meta($post_id, '_sap_fb_status');
		$_sap_tw_status = $this->get_post_meta($post_id, '_sap_tw_status');
		$_sap_li_status = $this->get_post_meta($post_id, '_sap_li_status');
		$_sap_tumblr_status = $this->get_post_meta($post_id, '_sap_tumblr_status');
		$_sap_pin_status = $this->get_post_meta($post_id, '_sap_pin_status');
		$_sap_gmb_status = $this->get_post_meta($post_id, '_sap_gmb_status');
		$_sap_reddit_status = $this->get_post_meta($post_id, '_sap_reddit_status');
		$_sap_blogger_status = $this->get_post_meta($post_id, '_sap_blogger_status');

		if (
			(
				(!empty($_sap_fb_status) && $_sap_fb_status === '1') &&
				(!empty($_sap_tw_status) && $_sap_tw_status === '1') &&
				(!empty($_sap_li_status) && $_sap_li_status === '1') &&
				(!empty($_sap_tumblr_status) && $_sap_tumblr_status === '1') &&
				(!empty($_sap_pin_status) && $_sap_pin_status === '1') &&
				(!empty($_sap_gmb_status) && $_sap_gmb_status === '1') &&
				(!empty($_sap_reddit_status) && $_sap_reddit_status === '1') &&
				(!empty($_sap_blogger_status) && $_sap_blogger_status === '1')

			)

		) {
			return "false";
		} else if (
			empty($_sap_fb_status) ||
			empty($_sap_tw_status) ||
			empty($_sap_li_status) ||
			empty($_sap_tumblr_status) ||
			empty($_sap_pin_status) ||
			empty($_sap_gmb_status) ||
			empty($_sap_reddit_status) ||
			empty($_sap_blogger_status)
		) {
			return "true";
		} else {
			return "true";
		}
	}

	/**
	 * Save post meta
	 * 
	 * @package Social Auto Poster
	 * @since 1.0.0
	 */
	public function save_post_meta()
	{

		//Call Upload class and upload media
		$meta_file_Upload = new FileUploader(array());

		if (isset($_POST['interval']) && !empty($_POST['interval'])) {

			$this->update_post_meta($_POST['id'], 'sap_schedule_interval', $_POST['interval']);
		}

		//Preapare Data global time 
		if (!empty($_POST['status']) && $_POST['status'] == 2 && (!empty($_POST['sap-schedule-from-time']) && !empty($_POST['sap-schedule-to-time']))) {
			$arr = [
				'from' => strtotime($_POST['sap-schedule-from-time']),
				'to' => strtotime($_POST['sap-schedule-to-time'])
			];


			$this->update_post_meta($_POST['id'], 'sap_schedule_time', $arr);


			$start_time = $this->getCronTime($_POST['sap-schedule-from-time']);

			$this->update_post_meta($_POST['id'], 'sap_schedule_cron_time', $start_time);
		}

		//Preapare Data individual facebook time
		if (!empty($_POST['individual_status']) && ($_POST['individual_status'] == 2 || $_POST['status'] == 2) && (!empty($_POST['sap-schedule-from-time-fb']) && !empty($_POST['sap-schedule-to-time-fb']))) {

			$arr = [
				'from' => strtotime($_POST['sap-schedule-from-time-fb']),
				'to' => strtotime($_POST['sap-schedule-to-time-fb'])
			];

			$this->update_post_meta($_POST['id'], 'sap_schedule_time_fb', $arr);

			$start_time = $this->getCronTime($_POST['sap-schedule-from-time-fb']);

			$this->update_post_meta($_POST['id'], 'sap_schedule_cron_time_fb', $start_time);
		}

		//Preapare Data individual blogger time

		if (!empty($_POST['individual_status']) && ($_POST['individual_status'] == 2 || $_POST['status'] == 2) && (!empty($_POST['sap-schedule-from-time-blogger']) && !empty($_POST['sap-schedule-to-time-blogger']))) {

			$arr = [
				'from' => strtotime($_POST['sap-schedule-from-time-blogger']),
				'to' => strtotime($_POST['sap-schedule-to-time-blogger'])
			];

			$this->update_post_meta($_POST['id'], 'sap_schedule_time_blogger', $arr);


			$start_time = $this->getCronTime($_POST['sap-schedule-from-time-blogger']);

			$this->update_post_meta($_POST['id'], 'sap_schedule_cron_time_blogger', $start_time);
		}

		//Preapare Data twitter blogger time
		if (!empty($_POST['individual_status']) && ($_POST['individual_status'] == 2 || $_POST['status'] == 2) && (!empty($_POST['sap-schedule-from-time-tw']) && !empty($_POST['sap-schedule-to-time-tw']))) {

			$arr = [
				'from' => strtotime($_POST['sap-schedule-from-time-tw']),
				'to' => strtotime($_POST['sap-schedule-to-time-tw'])
			];
			$this->update_post_meta($_POST['id'], 'sap_schedule_time_tw', $arr);


			$start_time = $this->getCronTime($_POST['sap-schedule-from-time-tw']);

			$this->update_post_meta($_POST['id'], 'sap_schedule_cron_time_tw', $start_time);
		}

		//Preapare Data linkedin blogger time
		if (!empty($_POST['individual_status']) && ($_POST['individual_status'] == 2 || $_POST['status'] == 2) && (!empty($_POST['sap-schedule-from-time-li']) && !empty($_POST['sap-schedule-to-time-li']))) {

			$arr = [
				'from' => strtotime($_POST['sap-schedule-from-time-li']),
				'to' => strtotime($_POST['sap-schedule-to-time-li'])
			];
			$this->update_post_meta($_POST['id'], 'sap_schedule_time_li', $arr);


			$start_time = $this->getCronTime($_POST['sap-schedule-from-time-li']);

			$this->update_post_meta($_POST['id'], 'sap_schedule_cron_time_li', $start_time);
		}

		//Preapare Data tumblr blogger time
		if (!empty($_POST['individual_status']) && ($_POST['individual_status'] == 2 || $_POST['status'] == 2) && (!empty($_POST['sap-schedule-from-time-tumblr']) && !empty($_POST['sap-schedule-to-time-tumblr']))) {

			$arr = [
				'from' => strtotime($_POST['sap-schedule-from-time-tumblr']),
				'to' => strtotime($_POST['sap-schedule-to-time-tumblr'])
			];
			$this->update_post_meta($_POST['id'], 'sap_schedule_time_tumblr', $arr);


			$start_time = $this->getCronTime($_POST['sap-schedule-from-time-tumblr']);

			$this->update_post_meta($_POST['id'], 'sap_schedule_cron_time_tumblr', $start_time);
		}

		//Preapare Data pinterest blogger time
		if (!empty($_POST['individual_status']) && ($_POST['individual_status'] == 2 || $_POST['status'] == 2) && (!empty($_POST['sap-schedule-from-time-pin']) && !empty($_POST['sap-schedule-to-time-pin']))) {

			$arr = [
				'from' => strtotime($_POST['sap-schedule-from-time-pin']),
				'to' => strtotime($_POST['sap-schedule-to-time-pin'])
			];
			$this->update_post_meta($_POST['id'], 'sap_schedule_time_pin', $arr);



			$start_time = $this->getCronTime($_POST['sap-schedule-from-time-pin']);

			$this->update_post_meta($_POST['id'], 'sap_schedule_cron_time_pin', $start_time);
		}

		//Preapare Data gmb blogger time
		if (!empty($_POST['individual_status']) && ($_POST['individual_status'] == 2 || $_POST['status'] == 2) && (!empty($_POST['sap-schedule-from-time-gmb']) && !empty($_POST['sap-schedule-to-time-gmb']))) {

			$arr = [
				'from' => strtotime($_POST['sap-schedule-from-time-gmb']),
				'to' => strtotime($_POST['sap-schedule-to-time-gmb'])
			];
			$this->update_post_meta($_POST['id'], 'sap_schedule_time_gmb', $arr);


			$start_time = $this->getCronTime($_POST['sap-schedule-from-time-gmb']);

			$this->update_post_meta($_POST['id'], 'sap_schedule_cron_time_gmb', $start_time);
		}

		//Preapare Data instagram blogger time
		if (!empty($_POST['individual_status']) && ($_POST['individual_status'] == 2 || $_POST['status'] == 2) && (!empty($_POST['sap-schedule-from-time-instagram']) && !empty($_POST['sap-schedule-to-time-instagram']))) {

			$arr = [
				'from' => strtotime($_POST['sap-schedule-from-time-instagram']),
				'to' => strtotime($_POST['sap-schedule-to-time-instagram'])
			];
			$this->update_post_meta($_POST['id'], 'sap_schedule_time_instagram', $arr);


			$start_time = $this->getCronTime($_POST['sap-schedule-from-time-instagram']);

			$this->update_post_meta($_POST['id'], 'sap_schedule_cron_time_instagram', $start_time);
		}

		//Preapare Data reddit blogger time
		if (!empty($_POST['individual_status']) && ($_POST['individual_status'] == 2 || $_POST['status'] == 2) && (!empty($_POST['sap-schedule-from-time-reddit']) && !empty($_POST['sap-schedule-to-time-reddit']))) {

			$arr = [
				'from' => strtotime($_POST['sap-schedule-from-time-reddit']),
				'to' => strtotime($_POST['sap-schedule-to-time-reddit'])
			];
			$this->update_post_meta($_POST['id'], 'sap_schedule_time_reddit', $arr);

			$start_time = $this->getCronTime($_POST['sap-schedule-from-time-reddit']);

			$this->update_post_meta($_POST['id'], 'sap_schedule_cron_time_reddit', $start_time);
		}


		if (!empty($_POST['networks'])) {
			$this->update_post_meta($_POST['id'], 'sap_networks', $_POST['networks']);
		}

		//Upload custom image if exist
		if (!empty($_FILES['sap_facebbok_post_img']['name'])) {
			$_POST['sap_facebbok_post_img'] = $meta_file_Upload->uploadFile('sap_facebbok_post_img');
		}

		if (isset($_POST['fb_ai_image_link']) && !empty($_POST['fb_ai_image_link'])) {
			$_POST['sap_facebbok_post_img'] =  $this->settings->uploadImageFromUrl($_POST['fb_ai_image_link']);
		}

		$fb_prefix = '_sap_fb_post_';

		$prepare_fb_post_meta = array(
			"msg" => !empty($_POST['sap_facebook']['message']) ? ($_POST['sap_facebook']['message']) : '',
			"accounts" => !empty($_POST['sap_facebook']['accounts']) ? ($_POST['sap_facebook']['accounts']) : '',
			"image" => !empty($_POST['sap_facebbok_post_img']) ? ($_POST['sap_facebbok_post_img']) : '',
			"title" => !empty($_POST['fb_title']) ? ($_POST['fb_title']) : '',
			"image_title" => !empty($_POST['fb_image_title']) ? ($_POST['fb_image_title']) : '',
			"word" => !empty($_POST['sap_chat_fb_word']) ? ($_POST['sap_chat_fb_word']) : '',
		);


		if (!empty($_POST['sap_facebook']['type'])) {
			$prepare_fb_post_meta['type'] = $_POST['sap_facebook']['type'];
		}

		if (!empty($prepare_fb_post_meta)) {
			foreach ($prepare_fb_post_meta as $meta_key => $meta_value) {
				$this->update_post_meta($_POST['id'], $fb_prefix . $meta_key, $meta_value);
			}
		}

		//Prepare Data for Instagram
		$insta_prefix = '_sap_instagram_post_';
		//Prepare Data for GMB
		if (!empty($_FILES['sap_instagram_post_img']['name'])) {
			$_POST['sap_instagram_post_img'] = $meta_file_Upload->uploadFile('sap_instagram_post_img');
		}

		if (isset($_POST['insta_ai_image_link']) && !empty($_POST['insta_ai_image_link'])) {
			$_POST['sap_instagram_post_img'] =  $this->settings->uploadImageFromUrl($_POST['insta_ai_image_link']);
		}

		$insta_post_meta = array(
			"msg" => !empty($_POST['sap_instagram']['message']) ? ($_POST['sap_instagram']['message']) : '',
			"accounts" => !empty($_POST['sap_instagram']['accounts']) ? ($_POST['sap_instagram']['accounts']) : '',
			"image" => !empty($_POST['sap_instagram_post_img']) ? ($_POST['sap_instagram_post_img']) : '',
			"title" => !empty($_POST['insta_title']) ? ($_POST['insta_title']) : '',
			"image_title" => !empty($_POST['insta_image_title']) ? ($_POST['insta_image_title']) : '',
			"word" => !empty($_POST['sap_chat_insta_word']) ? ($_POST['sap_chat_insta_word']) : '',
		);

		if (!empty($insta_post_meta)) {
			foreach ($insta_post_meta as $meta_key => $meta_value) {

				$this->update_post_meta($_POST['id'], $insta_prefix . $meta_key, $meta_value);
			}
		}


		//Prepare Data for Reddit
		$reddit_prefix = '_sap_reddit_post_';

		if (!empty($_FILES['sap_reddit_post_img']['name'])) {
			$_POST['sap_reddit_post_img'] = $meta_file_Upload->uploadFile('sap_reddit_post_img');
		}

		if (isset($_POST['reddit_ai_image_link']) && !empty($_POST['reddit_ai_image_link'])) {
			$_POST['sap_reddit_post_img'] =  $this->settings->uploadImageFromUrl($_POST['reddit_ai_image_link']);
		}

		$reddit_post_meta = array(
			"type" => !empty($_POST['sap_reddit_post_type']) ? ($_POST['sap_reddit_post_type']) : '',
			"msg" => !empty($_POST['sap_reddit_msg']) ? ($_POST['sap_reddit_msg']) : '',
			"accounts" => !empty($_POST['sap_reddit_user_id']) ? ($_POST['sap_reddit_user_id']) : '',
			"img" => !empty($_POST['sap_reddit_post_img']) ? ($_POST['sap_reddit_post_img']) : '',
			"title" => !empty($_POST['reddit_title']) ? ($_POST['reddit_title']) : '',
			"image_title" => !empty($_POST['reddit_image_title']) ? ($_POST['reddit_image_title']) : '',
			"word" => !empty($_POST['sap_chat_reddit_word']) ? ($_POST['sap_chat_reddit_word']) : '',
		);

		if (!empty($reddit_post_meta)) {
			foreach ($reddit_post_meta as $meta_key => $meta_value) {

				$this->update_post_meta($_POST['id'], $reddit_prefix . $meta_key, $meta_value);
			}
		}


		//Prepare Data for Blogger
		$blogger_prefix = '_sap_blogger_post_';

		if (!empty($_FILES['sap_blogger_post_img']['name'])) {
			$_POST['sap_blogger_post_img'] = $meta_file_Upload->uploadFile('sap_blogger_post_img');
		}


		if (isset($_POST['blogger_ai_image_link']) && !empty($_POST['blogger_ai_image_link'])) {
			$_POST['sap_blogger_post_img'] =  $this->settings->uploadImageFromUrl($_POST['blogger_ai_image_link']);
		}

		$blogger_post_meta = array(
			"title" => !empty($_POST['sap_blogger_title']) ? ($_POST['sap_blogger_title']) : '',
			"accounts" => !empty($_POST['sap_blogger_user_id']) ? ($_POST['sap_blogger_user_id']) : '',
			"img" => !empty($_POST['sap_blogger_post_img']) ? ($_POST['sap_blogger_post_img']) : '',
			"url" => !empty($_POST['sap_blogger_url']) ? ($_POST['sap_blogger_url']) : '',
			"image_title" => !empty($_POST['blogger_image_title']) ? ($_POST['blogger_image_title']) : '',
		);

		if (!empty($blogger_post_meta)) {
			foreach ($blogger_post_meta as $meta_key => $meta_value) {
				$this->update_post_meta($_POST['id'], $blogger_prefix . $meta_key, $meta_value);
			}
		}


		//Prepare Data for GMB
		if (!empty($_FILES['sap_gmb_post_img']['name'])) {
			$_POST['sap_gmb_post_img'] = $meta_file_Upload->uploadFile('sap_gmb_post_img');
		}

		if (isset($_POST['gmb_ai_image_link']) && !empty($_POST['gmb_ai_image_link'])) {
			$_POST['sap_gmb_post_img'] =  $this->settings->uploadImageFromUrl($_POST['gmb_ai_image_link']);
		}

		$gmb_prefix = '_sap_gmb_post_';
		$prepare_gmb_post_meta = array(
			"msg" => !empty($_POST['sap_gmb']['message']) ? ($_POST['sap_gmb']['message']) : '',
			"link" => !empty($_POST['sap_gmb_custom_link']) ? ($_POST['sap_gmb_custom_link']) : '',
			"accounts" => !empty($_POST['sap_gmb']['accounts']) ? ($_POST['sap_gmb']['accounts']) : '',
			"image" => !empty($_POST['sap_gmb_post_img']) ? ($_POST['sap_gmb_post_img']) : '',
			"image_title" => !empty($_POST['gmb_image_title']) ? ($_POST['gmb_image_title']) : '',
			"title" => !empty($_POST['gmb_title']) ? ($_POST['gmb_title']) : '',
			"word" => !empty($_POST['sap_chat_gmb_word']) ? ($_POST['sap_chat_gmb_word']) : '',
			'button_type' => !empty($_POST['sap_gmb']['gmb_button_type']) ? ($_POST['sap_gmb']['gmb_button_type']) : ''
		);

		if (!empty($prepare_gmb_post_meta)) {
			foreach ($prepare_gmb_post_meta as $meta_key => $meta_value) {

				$this->update_post_meta($_POST['id'], $gmb_prefix . $meta_key, $meta_value);
			}
		}


		//Preapare Data of Twitter custom
		$tw_prefix = '_sap_tw_';

		$prepare_tw_post_meta = array(
			"msg" => !empty($_POST['sap_twitter_msg']) ? $_POST['sap_twitter_msg'] : '',
			"template" => '',
			"accounts" => !empty($_POST['sap_twitter_user_id']) ? ($_POST['sap_twitter_user_id']) : '',
			"image_title" => !empty($_POST['tw_image_title']) ? ($_POST['tw_image_title']) : '',
			"title" => !empty($_POST['tw_title']) ? ($_POST['tw_title']) : '',
			"word" => !empty($_POST['sap_chat_tw_word']) ? ($_POST['sap_chat_tw_word']) : '',
		);

		if (!empty($_FILES['sap_tweet_img']['name'])) {
			$prepare_tw_post_meta["image"] = $meta_file_Upload->uploadFile('sap_tweet_img');
		} else {
			$prepare_tw_post_meta["image"] = !empty($_POST['sap_tweet_img']) ? $_POST['sap_tweet_img'] : '';
		}

		if (isset($_POST['tw_ai_image_link']) && !empty($_POST['tw_ai_image_link'])) {
			$prepare_tw_post_meta['image'] =  $this->settings->uploadImageFromUrl($_POST['tw_ai_image_link']);
		}

		if (!empty($prepare_tw_post_meta)) {
			foreach ($prepare_tw_post_meta as $meta_key => $meta_value) {
				$this->update_post_meta($_POST['id'], $tw_prefix . $meta_key, $meta_value);
			}
		}


		//Preapare Data of Linkedin custom
		$li_prefix = '_sap_li_post_';

		$prepare_li_post_meta = array(
			"title" => !empty($_POST['sap_linkedin_custom_title']) ? ($_POST['sap_linkedin_custom_title']) : '',
			"desc" => !empty($_POST['sap_linkedin_custom_description']) ? ($_POST['sap_linkedin_custom_description']) : '',
			"link" => !empty($_POST['sap_linkedin_custom_link']) ? ($_POST['sap_linkedin_custom_link']) : '',
			"image_title" => !empty($_POST['li_image_title']) ? ($_POST['li_image_title']) : '',
			"profile" => !empty($_POST['sap_linkedin_user_id']) ? (implode(',', $_POST['sap_linkedin_user_id'])) : '',
			"word" => !empty($_POST['sap_chat_li_word']) ? ($_POST['sap_chat_li_word']) : '',

		);

		//Upload custom image if exist
		if (!empty($_FILES['sap_linkedin_post_img']['name'])) {
			$prepare_li_post_meta['image'] = $meta_file_Upload->uploadFile('sap_linkedin_post_img');
		} else {
			$prepare_li_post_meta["image"] = !empty($_POST['sap_linkedin_post_img']) ? $_POST['sap_linkedin_post_img'] : '';
		}


		if (isset($_POST['li_ai_image_link']) && !empty($_POST['li_ai_image_link'])) {
			$prepare_li_post_meta['image'] =  $this->settings->uploadImageFromUrl($_POST['li_ai_image_link']);
		}

		if (!empty($prepare_li_post_meta)) {
			foreach ($prepare_li_post_meta as $meta_key => $meta_value) {
				$this->update_post_meta($_POST['id'], $li_prefix . $meta_key, $meta_value);
			}
		}

		//Preapare Data of Tumblr custom
		$tb_prefix = '_sap_tumblr_post_';

		$prepare_tb_post_meta = array(
			"type" => !empty($_POST['sap_tumblr_posting_type']) ? ($_POST['sap_tumblr_posting_type']) : '',
			"link" => !empty($_POST['sap_tumblr_custom_link']) ? ($_POST['sap_tumblr_custom_link']) : '',
			"desc" => !empty($_POST['sap_tumblr_custom_description']) ? ($_POST['sap_tumblr_custom_description']) : '',
			"image_title" => !empty($_POST['tumblr_image_title']) ? ($_POST['tumblr_image_title']) : '',
			"custom_title" => !empty($_POST['sap_tumblr_custom_title']) ? ($_POST['sap_tumblr_custom_title']) : '',
			"profile" => !empty($_POST['sap_tumblr_user_id']) ? (implode(',', $_POST['sap_tumblr_user_id'])) : '',
			"word" => !empty($_POST['sap_chat_tumblr_word']) ? ($_POST['sap_chat_tumblr_word']) : '',
		);

		//Upload custom image if exist
		if (!empty($_FILES['sap_tumblr_post_img']['name'])) {
			$prepare_tb_post_meta['img'] = $meta_file_Upload->uploadFile('sap_tumblr_post_img');
		} else {
			$prepare_tb_post_meta["img"] = !empty($_POST['sap_tumblr_post_img']) ? $_POST['sap_tumblr_post_img'] : '';
		}

		if (isset($_POST['tmblr_ai_image_link']) && !empty($_POST['tmblr_ai_image_link'])) {
			$prepare_tb_post_meta['img'] =  $this->settings->uploadImageFromUrl($_POST['tmblr_ai_image_link']);
		}

		if (!empty($prepare_tb_post_meta)) {
			foreach ($prepare_tb_post_meta as $meta_key => $meta_value) {
				$this->update_post_meta($_POST['id'], $tb_prefix . $meta_key, $meta_value);
			}
		}


		//Preapare Data of Pinterest custom
		//Upload custom image if exist
		if (!empty($_FILES['sap_pinterest_post_img']['name'])) {
			$_POST['sap_pinterest_post_img'] = $meta_file_Upload->uploadFile('sap_pinterest_post_img');
		}

		if (isset($_POST['pin_ai_image_link']) && !empty($_POST['pin_ai_image_link'])) {
			$_POST['sap_pinterest_post_img'] =  $this->settings->uploadImageFromUrl($_POST['pin_ai_image_link']);
		}
		$pin_prefix = '_sap_pin_post_';

		$prepare_pin_post_meta = array(
			"msg"       => !empty($_POST['sap_pinterest']['message']) ? ($_POST['sap_pinterest']['message']) : '',
			"accounts"    => !empty($_POST['sap_pinterest']['accounts']) ? ($_POST['sap_pinterest']['accounts']) : '',
			"image"       => !empty($_POST['sap_pinterest_post_img']) ? ($_POST['sap_pinterest_post_img']) : '',
			"title"       => !empty($_POST['pin_title']) ? ($_POST['pin_title']) : '',
			"image_title"       => !empty($_POST['pin_image_title']) ? ($_POST['pin_image_title']) : '',
			"word"       => !empty($_POST['sap_chat_pin_word']) ? ($_POST['sap_chat_pin_word']) : '',
		);

		if (!empty($prepare_pin_post_meta)) {
			foreach ($prepare_pin_post_meta as $meta_key => $meta_value) {
				$this->update_post_meta($_POST['id'], $pin_prefix . $meta_key, $meta_value);
			}
		}
	}

	/**
	 * Handle all Socail posts
	 * @package Social Auto Poster
	 * @since 1.0.0
	 */
	public function sap_manage_wall_social_post($post_id, $scheduled = false, $user_id = '', $individual_post = false)
	{



		// If current user then take accesible netwroks from session
		$networks = sap_get_users_networks_by_id($user_id);

		$networks = unserialize($networks->networks);

		//Call Upload class and upload media
		$fileUpload = new FileUploader(array());

		//Get general options of Facebook;
		$sap_facebook_options = array();

		if (in_array('facebook', $networks)) {

			$sap_facebook_options = $this->settings->get_user_setting('sap_facebook_options', $user_id);

			$sap_facebook_options = !empty($sap_facebook_options) ? $sap_facebook_options : array();
		}

		//Get general options of Twiiter;
		$sap_twitter_options = array();
		if (in_array('twitter', $networks)) {
			$sap_twitter_options = $this->settings->get_user_setting('sap_twitter_options', $user_id);
			$sap_twitter_options = !empty($sap_twitter_options) ? $sap_twitter_options : array();
		}

		//Get general options of linkedin;
		$sap_linkedin_options = array();
		if (in_array('linkedin', $networks)) {
			$sap_linkedin_options = $this->settings->get_user_setting('sap_linkedin_options', $user_id);
			$sap_linkedin_options = !empty($sap_linkedin_options) ? $sap_linkedin_options : array();
		}

		//Get general options of Tumblr;
		$sap_tumblr_options = array();
		if (in_array('tumblr', $networks)) {
			$sap_tumblr_options = $this->settings->get_user_setting('sap_tumblr_options', $user_id);
			$sap_tumblr_options = !empty($sap_tumblr_options) ? $sap_tumblr_options : array();
		}

		//Get general options of Google My Business
		$sap_gmb_options = array();
		if (in_array('gmb', $networks)) {
			$sap_gmb_options = $this->settings->get_user_setting('sap_google_business_options', $user_id);
			$sap_gmb_options = !empty($sap_gmb_options) ? $sap_gmb_options : array();
		}

		$sap_pinterest_options = array();
		if (in_array('pinterest', $networks)) {
			$sap_pinterest_options = $this->settings->get_user_setting('sap_pinterest_options', $user_id);
			$sap_pinterest_options = !empty($sap_pinterest_options) ? $sap_pinterest_options : array();
		}

		$sap_instagram_options = array();
		if (in_array('instagram', $networks)) {
			$sap_instagram_options = $this->settings->get_user_setting('sap_instagram_options', $user_id);
			$sap_instagram_options = !empty($sap_instagram_options) ? $sap_instagram_options : array();
		}

		//Get Redit options
		$sap_reddit_options = array();

		if (in_array('reddit', $networks)) {
			$sap_reddit_options = $this->settings->get_user_setting('sap_reddit_options', $user_id);

			$sap_reddit_options = !empty($sap_reddit_options) ? $sap_reddit_options : array();
		}

		//Get Blogger options
		$sap_blogger_options = array();

		if (in_array('blogger', $networks)) {
			$sap_blogger_options = $this->settings->get_user_setting('sap_blogger_options');

			$sap_blogger_options = !empty($sap_blogger_options) ? $sap_blogger_options : array();
		}


		//Check post first time inserting or updating...
		$sap_fb_status = $this->get_post_meta($post_id, '_sap_fb_status');
		$schedule_time_fb = $this->get_post_meta($post_id, 'sap_schedule_time_fb');

		// if facebook is enable and sap_fb_status is empty or 2 then go inside if condition
		//Check facebook enable
		if (!empty($sap_facebook_options['enable_facebook']) && $sap_fb_status != '1' && $sap_fb_status != '3') {

			//Check schedule enable
			if (!empty($_POST['status']) && $_POST['status'] == 2 && $scheduled == 2) {
				$this->update_post_meta($post_id, '_sap_fb_status', 2);
				$this->flash->setFlash($this->sap_common->lang('content_scheduled_fb'), 'success');
			} else {

				// if individual schedule time is not set and individual_post  parameter is false then post with global time
				// if individual schedule time is set and individual_post parameter is fb given then post with individual time
				if ((empty($schedule_time_fb) && $individual_post == false) || $individual_post == 'fb') {

					if (!class_exists('SAP_Facebook')) {
						require_once(CLASS_PATH . 'Social' . DS . 'fbConfig.php');
					}

					$facebook = new SAP_Facebook($user_id);
					$prefix = '_sap_fb_post_';


					$fb_result = $facebook->sap_fb_post_to_userwall($post_id);

					if (!empty($fb_result)) {
						$this->update_post_meta($post_id, '_sap_fb_status', '1');
					} else {
						// '3' for tried to published when schedule time occur but error occur  
						$this->update_post_meta($post_id, '_sap_fb_status', '3');
					}
				}
			}
		}

		//Check post first time inserting or updating...
		//Check Reddit enable
		$sap_reddit_status = $this->get_post_meta($post_id, '_sap_reddit_status');
		$schedule_time_reddit = $this->get_post_meta($post_id, 'sap_schedule_time_reddit');

		if (!empty($sap_reddit_options['enable_reddit']) && $sap_reddit_status != '1' && $sap_reddit_status != '3') {

			//Check schedule enable
			if (!empty($_POST['status']) && $_POST['status'] == 2 && $scheduled == 2) {
				$this->update_post_meta($post_id, '_sap_reddit_status', 2);
				$this->flash->setFlash($this->sap_common->lang('content_scheduled_reddit'), 'success');
			} else {
				if ((empty($schedule_time_reddit) && $individual_post == false) || $individual_post == 'reddit') {
					if (!class_exists('SAP_Reddit')) {
						require_once(CLASS_PATH . 'Social' . DS . 'redditConfig.php');
					}

					$reddit = new SAP_Reddit($user_id);
					$prefix = '_sap_reddit_post_';

					$reddit_result = $reddit->sap_reddit_post_to_userwall($post_id);


					if (!empty($reddit_result)) {
						$this->update_post_meta($post_id, '_sap_reddit_status', '1');
					} else {
						// '3' for tried to published when schedule time occur but error occur  
						$this->update_post_meta($post_id, '_sap_reddit_status', '3');
					}
				}
			}
		}

		//Check Blogger enable
		$sap_blogger_status = $this->get_post_meta($post_id, '_sap_blogger_status');
		$schedule_time_blogger = $this->get_post_meta($post_id, 'sap_schedule_time_blogger');

		if (!empty($sap_blogger_options['enable_blogger']) && $sap_blogger_status != '1' && $sap_blogger_status != '3') {
			//Check schedule enable
			if (!empty($_POST['status']) && $_POST['status'] == 2 && $scheduled == 2) {
				$this->update_post_meta($post_id, '_sap_blogger_status', 2);
				$this->flash->setFlash($this->sap_common->lang('content_scheduled_blogger'), 'success');
			} else {
				if ((empty($schedule_time_blogger) && $individual_post == false) || $individual_post == 'blogger') {
					if (!class_exists('SAP_Blogger')) {
						require_once(CLASS_PATH . 'Social' . DS . 'bloggerConfig.php');
					}

					$blogger = new SAP_Blogger($user_id);
					$prefix = '_sap_blogger_post_';

					$blogger_result = $blogger->sap_blogger_post_to_userwall($post_id);

					if (!empty($blogger_result)) {
						$this->update_post_meta($post_id, '_sap_blogger_status', '1');
					} else {
						// '3' for tried to published when schedule time occur but error occur  
						$this->update_post_meta($post_id, '_sap_blogger_status', '3');
					}
				}
			}
		}


		$sap_tw_status = $this->get_post_meta($post_id, '_sap_tw_status');
		$schedule_time_twitter = $this->get_post_meta($post_id, 'sap_schedule_time_tw');

		//Check twitter enable
		if (!empty($sap_twitter_options['enable_twitter']) && $sap_tw_status != '1' && $sap_tw_status != '3') {

			//Check schedule enable
			if (!empty($_POST['status']) && $_POST['status'] == 2 && $scheduled == 2) {
				$this->update_post_meta($post_id, '_sap_tw_status', 2);
				$this->flash->setFlash($this->sap_common->lang('content_scheduled_twitter'), 'success');
			} else {
				if ((empty($schedule_time_twitter) && $individual_post == false) || $individual_post == 'twitter') {

					//Upload custom image if exist
					if (!class_exists('SAP_Twitter')) {
						require_once(CLASS_PATH . 'Social' . DS . 'twitterConfig.php');
					}

					$this->twposting = new SAP_Twitter($user_id);

					$prefix = '_sap_tw_';

					$tw_result = $this->twposting->sap_post_to_twitter($post_id);

					if (!empty($tw_result)) {
						$this->update_post_meta($post_id, '_sap_tw_status', '1');
					} else {
						// '3' for tried to published when schedule time occur but error occur  
						$this->update_post_meta($post_id, '_sap_tw_status', '3');
					}
				}
			}
		}

		$sap_li_status = $this->get_post_meta($post_id, '_sap_li_status');
		$schedule_time_linkedin = $this->get_post_meta($post_id, 'sap_schedule_time_li');

		//Check Linkedin enable
		if (!empty($sap_linkedin_options['enable_linkedin']) && $sap_li_status != '1' && $sap_li_status != '3') {

			//Check schedule enable
			if (!empty($_POST['status']) && $_POST['status'] == 2 && $scheduled == 2) {
				$this->update_post_meta($post_id, '_sap_li_status', 2);
				$this->flash->setFlash($this->sap_common->lang('content_scheduled_li'), 'success');
			} else {
				if ((empty($schedule_time_linkedin) && $individual_post == false) || $individual_post == 'linkedin') {

					if (!class_exists('SAP_Linkedin')) {
						require_once(CLASS_PATH . 'Social' . DS . 'liConfig.php');
					}

					$linkedin = new SAP_Linkedin($user_id);
					$prefix = '_sap_li_post_';

					$li_result = $linkedin->sap_post_to_linkedin($post_id);

					if (!empty($li_result['success'])) {
						$this->update_post_meta($post_id, '_sap_li_status', '1');
					} else {
						// '3' for tried to published when schedule time occur but error occur  
						$this->update_post_meta($post_id, '_sap_li_status', '3');
					}
				}
			}
		}

		$sap_tu_status = $this->get_post_meta($post_id, '_sap_tumblr_status');
		$schedule_time_tumblr = $this->get_post_meta($post_id, 'sap_schedule_time_tumblr');

		//Check Tumblr enable

		if (!empty($sap_tumblr_options['enable_tumblr']) && $sap_tu_status != '1' && $sap_tu_status != '3') {

			//Check schedule enable
			if (!empty($_POST['status']) && $_POST['status'] == 2 && $scheduled == 2) {
				$this->update_post_meta($post_id, '_sap_tumblr_status', 2);
				$this->flash->setFlash($this->sap_common->lang('content_scheduled_tumb'), 'success');
			} else {
				if ((empty($schedule_time_tumblr) && $individual_post == false) || $individual_post == 'tumblr') {

					if (!class_exists('SAP_Tumblr')) {
						require_once(CLASS_PATH . 'Social' . DS . 'tumblrConfig.php');
					}

					$tumblr = new SAP_Tumblr($user_id);
					$prefix = '_sap_tumblr_post_';

					$tm_result = $tumblr->sap_post_to_tumblr($post_id);
					if ((isset($tm_result) && $tm_result['status'] == 'published') || ($tm_result['status'] == 'transcoding' && $tm_result['posting_type'] == 'video')) {
						$this->update_post_meta($post_id, '_sap_tumblr_status', '1');
					} else {
						// '3' for tried to published when schedule time occur but error occur  
						$this->update_post_meta($post_id, '_sap_tumblr_status', '3');
					}
				}
			}
		}

		//Intagram posting method  
		$sap_instagram_status = $this->get_post_meta($post_id, '_sap_instagram_status');
		$schedule_time_instagram = $this->get_post_meta($post_id, 'sap_schedule_time_instagram');

		if (!empty($sap_instagram_options['enable_instagram']) && $sap_instagram_status != '1' && $sap_instagram_status != '3') {

			if (!empty($_POST['status']) && $_POST['status'] == 2 && $scheduled == 2) {
				$this->update_post_meta($post_id, '_sap_instagram_status', 2);
				$this->flash->setFlash($this->sap_common->lang('content_scheduled_instagram'), 'success');
			} else {
				if ((empty($schedule_time_instagram) && $individual_post == false) || $individual_post == 'instagram') {

					if (!class_exists('SAP_Instagram')) {
						require_once(CLASS_PATH . 'Social' . DS . 'instaConfig.php');
					}

					$instagram = new SAP_Instagram($user_id);
					$prefix = '_sap_instagram_post';

					$result = $instagram->sap_instagram_post_to_userwall($post_id);

					if (isset($result) && $result) {
						$this->update_post_meta($post_id, '_sap_instagram_status', '1');
					} else {
						// '3' for tried to published when schedule time occur but error occur  
						$this->update_post_meta($post_id, '_sap_instagram_status', '3');
					}
				}
			}
		}

		//Check post first time inserting or updating... Google My Business
		$sap_gmb_status = $this->get_post_meta($post_id, '_sap_gmb_status');
		$schedule_time_gmb = $this->get_post_meta($post_id, 'sap_schedule_time_gmb');

		if (!empty($sap_gmb_options['enable_google_business']) && $sap_gmb_status != '1' && $sap_gmb_status != '3') {

			if (!empty($_POST['status']) && $_POST['status'] == 2 && $scheduled == 2) {
				$this->update_post_meta($post_id, '_sap_gmb_status', 2);
				$this->flash->setFlash($this->sap_common->lang('content_scheduled_gmb'), 'success');
			} else {
				if ((empty($schedule_time_gmb) && $individual_post == false) || $individual_post == 'gmb') {

					if (!class_exists('SAP_Gmb')) {
						require_once(CLASS_PATH . 'Social' . DS . 'gmbConfig.php');
					}

					$google_business = new SAP_Gmb($user_id);
					$prefix = '_sap_gmb_post';

					$gmb_result = $google_business->sap_send_post_to_gmb($post_id);

					if (isset($gmb_result['success']) && $gmb_result['success'] == '1') {
						$this->update_post_meta($post_id, '_sap_gmb_status', '1');
					} else {
						// '3' for tried to published when schedule time occur but error occur  
						$this->update_post_meta($post_id, '_sap_gmb_status', '3');
					}
				}
			}
		}

		//Check post first time inserting or updating...
		$sap_pin_status = $this->get_post_meta($post_id, '_sap_pin_status');
		$schedule_time_pinterest = $this->get_post_meta($post_id, 'sap_schedule_time_pin');

		//Check pinterest enable
		if (!empty($sap_pinterest_options['enable_pinterest']) && $sap_pin_status != '1' && $sap_pin_status != '3') {

			//Check schedule enable
			if (!empty($_POST['status']) && $_POST['status'] == 2 && $scheduled == 2) {
				$this->update_post_meta($post_id, '_sap_pin_status', 2);
				$this->flash->setFlash($this->sap_common->lang('content_scheduled_pit'), 'success');
			} else {
				if ((empty($schedule_time_pinterest) && $individual_post == false) || $individual_post == 'pinterest') {

					if (!class_exists('SAP_Pinterest')) {
						require_once(CLASS_PATH . 'Social' . DS . 'pinConfig.php');
					}

					$pinterest = new SAP_Pinterest($user_id);
					$prefix = '_sap_pin_post_';

					$pin_result = $pinterest->sap_pin_post_to_userwall($post_id);

					if ($pin_result) {
						$this->update_post_meta($post_id, '_sap_pin_status', '1');
					} else {
						// '3' for tried to published when schedule time occur but error occur  
						$this->update_post_meta($post_id, '_sap_pin_status', '3');
					}
				}
			}
		}
	}

	/**
	 * Short the Content As Per Character Limit
	 * 
	 * Handles to return short content as per character 
	 * limit
	 * 
	 * @package Social Auto Poster
	 * */
	public function sap_limit_character($content, $charlength = 140)
	{

		$excerpt = '';
		$charlength++;

		//check content length is greater then character length
		if (strlen($content) > $charlength) {

			$subex = substr($content, 0, $charlength - 5);
			$exwords = explode(' ', $subex);
			$excut = - (strlen($exwords[count($exwords) - 1]));

			if ($excut < 0) {
				$excerpt = substr($subex, 0, $excut);
			} else {
				$excerpt = $subex;
			}
		} else {
			$excerpt = $content;
		}

		//return short content
		return $excerpt;
	}


	/**
	 * Get all supported Networks
	 * 
	 * @package Social Auto Poster
	 * @since 1.0.0
	 */
	public function sap_get_supported_networks()
	{
		return array(
			'fb' => 'facebook',
			'tw' => 'twitter',
			'li' => 'linkedin',
			'tb' => 'tumblr',
			'reddit' => 'reddit',
			'blogger' => 'blogger',
		);
	}


	public function getCronTime($time)
	{
		if (isset($_POST['interval']) && !empty($_POST['interval'])) {

			$intervalTime = explode(' ', $_POST['interval']);
			$seconds = $intervalTime[0] * 3600;
			$start_time = strtotime($time) + $seconds;
		} else {
			$start_time = strtotime($time) + 3600;   // 1 Hour interval is default for publishing posts
		}

		return $start_time;
	}


	public function AiPost($post_id)
	{
		try {
			$postData = $this->db->get_row("SELECT * FROM `sap_posts` where `post_id` = '{$post_id}'", 'ARRAY_A');
			$postMetaData = $this->db->get_results("SELECT * FROM `sap_postmeta` where `post_id` = '{$post_id}'", 'ARRAY_A');
			$sap_networks_meta = $this->get_post_meta($post_id, 'sap_networks');

			// Initialize an empty array to store key-value pairs
			$savedPostData = array();

			// Iterate through each sub-array
			foreach ($postMetaData as $subArray) {
				// Extract meta_key and meta_value from each sub-array
				$key = $subArray['meta_key'];
				$value = $subArray['meta_value'];

				// Store key-value pair in the new array
				$savedPostData[$key] = $value;
			}

			$_POST['is_ai_post'] = true;

			$_POST['sap_ai_content_title']  = (!empty($postData->title)) ? $postData->title : $postData->share_link;
			$_POST['number_of_words']  = 30;
			$aiDescription = $this->quickPosts->sap_generate_description();

			$imageByAI  = $this->imageAiTitle('title', $postData);

			$_POST['networks'] = $sap_networks_meta;
			$_POST['title'] = isset($postData->title) ? $postData->title : '';
			$_POST['sap_chat_message'] = '30';
			$_POST['body'] = $aiDescription;
			$_POST['image_title'] = isset($postData->image_title) ? $postData->image_title : '';
			$_POST['ai_image_link'] = $imageByAI;
			$_POST['share_link'] = isset($postData->share_link) ? $postData->share_link : '';

			if (isset($sap_networks_meta['facebook']) && $sap_networks_meta['facebook']) {

				$fb_accounts =   $this->get_post_meta($post_id, '_sap_fb_post_accounts');

				$_POST['sap_facebook']['accounts'] = $fb_accounts;
				$_POST['sap_facebook']['type'] = isset($savedPostData['_sap_fb_post_type']) ? $savedPostData['_sap_fb_post_type'] : 'link_posting';

				$_POST['sap_facebook']['message'] =  isset($savedPostData['_sap_fb_post_title']) ? $this->descAiMessage('_sap_fb_post_title', $savedPostData) : ""; // ai generated 

				$_POST['sap_facebook_custom_link'] = isset($savedPostData[$key]) ? $savedPostData[$key] : '';
				$_POST['fb_title'] = isset($savedPostData['_sap_fb_post_title']) ? $savedPostData['_sap_fb_post_title'] : '';
				$_POST['sap_chat_fb_word'] = isset($savedPostData['_sap_fb_post_word']) ? $savedPostData['_sap_fb_post_word'] : 30;
				$_POST['fb_image_title'] = isset($savedPostData['_sap_fb_post_image_title']) ? $savedPostData['_sap_fb_post_image_title'] : '';
				$_POST['sap_facebbok_post_img'] = isset($savedPostData['_sap_fb_post_image']) ? $savedPostData['_sap_fb_post_image'] : '';
				$_POST['sap-schedule-from-time-fb'] = '';
				$_POST['sap-schedule-to-time-fb'] = '';
			}

			if (isset($sap_networks_meta['twitter']) && $sap_networks_meta['twitter']) {

				$tw_accounts =   $this->get_post_meta($post_id, '_sap_tw_accounts');

				$_POST['tw_title'] = isset($savedPostData['_sap_tw_title']) ? $savedPostData['_sap_tw_title'] : '';
				$_POST['sap_chat_tw_word'] = isset($savedPostData['_sap_tw_word']) ? $savedPostData['_sap_tw_word'] : 30;
				$_POST['tw_image_title'] = isset($savedPostData['_sap_tw_image_title']) ? $savedPostData['_sap_tw_image_title'] : '';
				$_POST['sap_tweet_img'] = isset($savedPostData['_sap_tw_image']) ? $savedPostData['_sap_tw_image'] : '';
				$_POST['sap_twitter_msg'] = isset($savedPostData['_sap_tw_title']) ? $this->descAiMessage('_sap_tw_title', $savedPostData) : ""; // ai generated 
				$_POST['sap_twitter_user_id'] = $tw_accounts;

				$_POST['sap-schedule-from-time-tw'] = '';
				$_POST['sap-schedule-to-time-tw'] = '';
			}

			if (isset($sap_networks_meta['linkedin']) && $sap_networks_meta['linkedin']) {

				$_POST['sap_linkedin_custom_link'] = isset($savedPostData['_sap_li_post_link']) ? $savedPostData['_sap_li_post_link'] : '';
				$_POST['sap_linkedin_custom_title'] = isset($savedPostData['_sap_li_post_title']) ? $savedPostData['_sap_li_post_title'] : '';
				$_POST['sap_chat_li_word'] = isset($savedPostData['_sap_li_post_word']) ? $savedPostData['_sap_li_post_word'] : '30';
				$_POST['li_image_title'] = isset($savedPostData['_sap_li_post_image_title']) ? $savedPostData['_sap_li_post_image_title'] : '';
				$_POST['sap_linkedin_post_img'] = isset($savedPostData['_sap_li_post_image']) ? $savedPostData['_sap_li_post_image'] : '';
				$_POST['sap_linkedin_custom_description'] = isset($savedPostData['_sap_li_post_title']) ? $this->descAiMessage('_sap_li_post_title', $savedPostData) : ""; // ai generated 
				$_POST['sap-schedule-from-time-li'] = '';
				$_POST['sap-schedule-to-time-li'] = '';
			}

			if (isset($sap_networks_meta['tumblr']) && $sap_networks_meta['tumblr']) {

				$_POST['sap_tumblr_posting_type'] = isset($savedPostData['_sap_tumblr_post_type']) ? $savedPostData['_sap_tumblr_post_type'] : '';
				$_POST['sap_tumblr_custom_link'] = isset($savedPostData['_sap_tumblr_post_link']) ? $savedPostData['_sap_tumblr_post_link'] : '';
				$_POST['tumblr_image_title'] = isset($savedPostData['_sap_tumblr_post_image_title']) ? $savedPostData['_sap_tumblr_post_image_title'] : '';
				$_POST['sap_tumblr_custom_title'] = isset($savedPostData['_sap_tumblr_post_title']) ? $savedPostData['_sap_tumblr_post_title'] : '';
				$_POST['sap_chat_tumblr_word'] = isset($savedPostData['sap_chat_tumblr_word']) ? $savedPostData['sap_chat_tumblr_word'] : '30';
				$_POST['sap_tumblr_custom_description'] =  isset($savedPostData['_sap_tumblr_post_title']) ? $this->descAiMessage('_sap_tumblr_post_title', $savedPostData) : "";  // ai generated 
				$_POST['sap-schedule-from-time-tumblr'] = '';
				$_POST['sap-schedule-to-time-tumblr'] = '';
			}

			if (isset($sap_networks_meta['pinterest']) && $sap_networks_meta['pinterest']) {

				$pin_accounts =   $this->get_post_meta($post_id, '_sap_pin_post_accounts');

				$_POST['sap_pinterest_custom_link'] = '';
				$_POST['pin_title'] = isset($savedPostData['_sap_pin_post_title']) ? $savedPostData['_sap_pin_post_title'] : '';
				$_POST['sap_chat_pin_word'] = '30';
				$_POST['pin_image_title'] = isset($savedPostData['_sap_pin_post_image_title']) ? $savedPostData['_sap_pin_post_image_title'] : '';
				$_POST['sap_pinterest_post_img'] = isset($savedPostData['_sap_pin_post_image']) ? $savedPostData['_sap_pin_post_image'] : '';
				$_POST['sap_pinterest']['message'] = isset($savedPostData['_sap_pin_post_image_title']) ? $this->descAiMessage('_sap_pin_post_image_title', $savedPostData) : "";  // ai generated 
				$_POST['sap_pinterest']['accounts'] = $pin_accounts;
				$_POST['sap-schedule-from-time-pin'] = '';
				$_POST['sap-schedule-to-time-pin'] = '';
			}


			if (isset($sap_networks_meta['gmb']) && $sap_networks_meta['gmb']) {
				$gmp_accounts =   $this->get_post_meta($post_id, '_sap_gmb_post_accounts');

				$_POST['sap_gmb']['gmb_button_type'] =  isset($savedPostData['_sap_gmb_post_button_type']) ? $savedPostData['_sap_gmb_post_button_type'] : '';
				$_POST['sap_gmb']['message'] =  isset($savedPostData['_sap_gmb_post_title']) ? $this->descAiMessage('_sap_gmb_post_title', $savedPostData) : "";  // ai generated 
				$_POST['sap_gmb']['accounts'] =  $gmp_accounts;

				$_POST['sap_gmb_custom_link'] = isset($savedPostData['_sap_gmb_post_link']) ? $savedPostData['_sap_gmb_post_link'] : '';
				$_POST['gmb_title'] = isset($savedPostData['_sap_gmb_post_title']) ? $savedPostData['_sap_gmb_post_title'] : '';
				$_POST['sap_chat_gmb_word'] = isset($savedPostData['_sap_gmb_post_word']) ? $savedPostData['_sap_gmb_post_word'] : '30';
				$_POST['gmb_image_title'] = isset($savedPostData['_sap_gmb_post_image_title']) ? $savedPostData['_sap_gmb_post_image_title'] : '';
				$_POST['sap-schedule-from-time-gmb'] = '';
				$_POST['sap-schedule-to-time-gmb'] = '';
			}

			if (isset($sap_networks_meta['instagram']) && $sap_networks_meta['instagram']) {
				$insta_accounts =  $this->get_post_meta($post_id, '_sap_instagram_post_accounts');

				$_POST['sap_facebook']['accounts'] = $fb_accounts;

				$_POST['insta_title'] = isset($savedPostData['_sap_instagram_post_title']) ? $savedPostData['_sap_instagram_post_title'] : '';
				$_POST['sap_chat_insta_word'] = isset($savedPostData['_sap_instagram_post_word']) ? $savedPostData['_sap_instagram_post_word'] : '30';
				$_POST['insta_image_title'] = isset($savedPostData['_sap_instagram_post_image_title']) ? $savedPostData['_sap_instagram_post_image_title'] : '';
				$_POST['sap_instagram']['message'] = isset($savedPostData['_sap_instagram_post_title']) ? $this->descAiMessage('_sap_instagram_post_title', $savedPostData) : "";  // ai generated 

				$_POST['sap_instagram']['accounts'] = $insta_accounts;
				$_POST['sap-schedule-from-time-instagram'] = '';
				$_POST['sap-schedule-to-time-instagram'] = '';
			}

			if (isset($sap_networks_meta['reddit']) && $sap_networks_meta['reddit']) {
				$reddit_accounts =   $this->get_post_meta($post_id, '_sap_reddit_post_accounts');

				$_POST['reddit_title'] = isset($savedPostData['_sap_reddit_post_title']) ? $savedPostData['_sap_reddit_post_title'] : '';
				$_POST['sap_chat_reddit_word'] = isset($savedPostData['_sap_reddit_post_word']) ? $savedPostData['_sap_reddit_post_word'] : '30';
				$_POST['reddit_image_title'] = isset($savedPostData['_sap_reddit_post_image_title']) ? $savedPostData['_sap_reddit_post_image_title'] : '';
				$_POST['sap_reddit_post_type'] = 'self';
				$_POST['sap_reddit_user_id'] = $reddit_accounts;
				$_POST['sap_reddit_msg'] = isset($savedPostData['_sap_reddit_post_title']) ? $this->descAiMessage('_sap_reddit_post_title', $savedPostData) : "";  // ai generated 
				$_POST['sap-schedule-from-time-reddit'] = '';
				$_POST['sap-schedule-to-time-reddit'] = '';
			}

			if (isset($sap_networks_meta['blogger']) && $sap_networks_meta['blogger']) {

				$blogger_accounts =   $this->get_post_meta($post_id, '_sap_blogger_post_accounts');

				$_POST['blogger_image_title'] = isset($savedPostData['_sap_blogger_post_image_title']) ? $savedPostData['_sap_blogger_post_image_title'] : '';
				$_POST['sap_blogger_title'] = isset($savedPostData['_sap_blogger_post_title']) ? $savedPostData['_sap_blogger_post_title'] : '';
				$_POST['sap_blogger_url'] = isset($savedPostData['_sap_blogger_post_url']) ? $savedPostData['_sap_blogger_post_url'] : '';
				$_POST['sap_blogger_user_id'] = $blogger_accounts;
				$_POST['sap-schedule-from-time-blogger'] = '';
				$_POST['sap-schedule-to-time-blogger'] = '';
			}


			$_POST['is_ai_post'] = true;
			$_POST['status'] = '1';
			$_POST['form-submitted'] = '1';
			$_POST['user_id'] = $postData->user_id;


			$result = 	$this->save_post();
			return true;
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}


	public function imageAiTitle($key, $postData)
	{
		$imageTitle = isset($savedPostData[$key]) ? $savedPostData[$key] : $postData->image_title;

		$data = [
			'is_ai_post' => true,
			'image_title' => $imageTitle
		];
		$_POST = $data;
		return $this->quickPosts->sap_generate_ai_image();
	}

	public function descAiMessage($key, $savedPostData)
	{
		$title = isset($savedPostData[$key]) ? $savedPostData[$key] : '';

		$data = [
			'is_ai_post' => true,
			'sap_ai_content_title' => $title,
			'number_of_words' => 30
		];

		return  $this->sap_generate_description($data);
	}


	public function sap_generate_description($data)
	{

		$number_of_words = $data['number_of_words'];
		$link = $data['sap_ai_content_title'];

		if (isset($data['is_ai_post'])) {
			$prompt = 'Give me an exciting and meaningfull  ' . $number_of_words . ' words social media caption for this :' . $link;
		} else {

			$prompt = 'Give me an exciting ' . $number_of_words . ' words social media caption for this :' . $link;
		}

		$api_key = $this->settings->get_options('sap_chatgpt_api_key');
		$open_ai = new OpenAi($api_key);
		$result = $open_ai->chatcompletions(array(
			'model' => 'gpt-3.5-turbo',
			'messages' => array(array('role' => 'user', 'content' => $prompt))
		));
		if (isset($data['is_ai_post'])) {

			$result = json_decode($result, true);
			return $result = $result['choices'][0]['message']['content'];
		} else {

			echo $result;
			exit();
		}
	}
}
